CREATE DATABASE IF NOT EXISTS `zabbix_proxy`;
GRANT ALL ON `zabbix_proxy`.* TO 'zabbix'@'%';
